# python-package-via-pip
Software Distribution - creating a small python package that can be installed via pip. This repo studies the start of open source projects that able others developers to use and easily contribute.
